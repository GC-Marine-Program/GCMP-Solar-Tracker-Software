#include <Arduino.h>

void led(int num);

void led(int num) {
  static char highPin[16] = {5, 6, 5, 7, 6, 7, 6, 8, 5, 8, 8, 7, 9, 7, 9, 8};
  static char lowPin[16] = {6, 5, 7, 5, 7, 6, 8, 6, 8, 5, 7, 8, 7, 9, 8, 9};

  for (int i = 5; i < 10; ++i) {
    pinMode(i, INPUT);
    digitalWrite(i, LOW);
  }
  if (num < 0) {
    return;
  }
  digitalWrite(highPin[num], HIGH);
  digitalWrite(lowPin[num], LOW);
  pinMode(highPin[num], OUTPUT);
  pinMode(lowPin[num], OUTPUT);
}
